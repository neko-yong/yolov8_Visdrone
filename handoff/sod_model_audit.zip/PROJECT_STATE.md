# PROJECT_STATE

## 1. 当前阶段

Stage B2 消融精细调优、SOD 交接与模型审计整理阶段。

## 2. 当前任务状态

- E03_full_sod_30ep_b5：已完成，输出目录 `runs/sod/E03_full_sod_30ep_b5`。
- E03_no_piou_50ep_b5：已完成，输出目录 `runs/sod/E03_no_piou_50ep_b5`。
- E03_batch8_full_50ep：异常卡死后人为中断，记录到 epoch 22，不作为最终结果。
- E03_batch8_full_50ep_workers0：存在 `results.csv`，当前审计观察到 6 行 epoch 记录，不能按 50ep 完成结果解读。
- `train.py` 已支持 `workers/cache/device`，Windows 默认 `workers=0`。
- 当前任务：生成 SOD 模型审计包 `handoff/sod_model_audit/`，供 Lite-SOD-A/B/C 分析。

## 3. 下一步任务

1. 基于 `handoff/sod_model_audit/SOD_MODEL_AUDIT.md` 分析 Lite-SOD-A/B/C 改造位置。
2. 优先以 no-PIoU SOD 作为轻量化对照基础。
3. 若改通道，必须逐层检查 Concat 输入通道和 Detect 输入通道。
4. 后续训练仍需遵守 Windows 长训 `workers=0`。

## 4. 已完成任务摘要

- YOLOv8s baseline 已训练完成并记录。
- GFPN-lite、P2 detection head、C2f-EMA、PIoU 已实现。
- Stage A 结构 smoke test 已完成。
- Stage B2 no-PIoU 对照已完成。
- 最小 SOD 交接包 `handoff/sod_handoff.zip` 已生成。
- SOD 模型审计包 `handoff/sod_model_audit.zip` 已生成。

## 5. 当前问题

- 当前 SOD 不是论文原版 1:1，而是 GFPN-lite + C2f-EMA + PIoU 的工程复现版本。
- full SOD + PIoU 当前表现可能弱于 baseline。
- PIoU 在当前复现条件下可能拉低 recall / mAP。
- batch8 长训在 Windows + YOLOv8 + DataLoader 场景下必须使用 `workers=0`。

## 6. 下一步建议

- Lite-SOD 优先从 neck/head 通道数和 Detect 前 Conv 入手。
- 不建议先改 Detect 输入顺序、stride 对应关系和训练入口稳定性逻辑。
- 冲 mAP50 时建议优先尝试 no-PIoU SOD + 更高分辨率微调。
