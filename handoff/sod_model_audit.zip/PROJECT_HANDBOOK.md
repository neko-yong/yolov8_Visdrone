# PROJECT_HANDBOOK

本文件是 Codex 运行规则手册，用于跨会话恢复项目状态。所有后续会话必须优先读取本文件与 `PROJECT_STATE.md`，再执行任何项目操作。

## 1. 项目概述

- 项目目标：复现 SOD-YOLO 在 VisDrone 小目标检测任务上的改进效果。
- 基础框架：YOLOv8 + Ultralytics。
- baseline：基于 YOLOv8s，在 VisDrone2019-DET 数据集上训练与验证。
- 主要指标：mAP50、mAP50-95、Precision、Recall。

## 2. 工程结构说明

- `datasets/`：VisDrone2019-DET 数据集与 YOLO 格式标注数据。
- `configs/`：数据集与训练配置文件，如 `configs/visdrone.yaml`。
- `models/`：模型结构配置与 SOD-YOLO 改进模块位置；当前目录未创建时视为预留结构。
- `scripts/`：数据转换、数据检查、实验辅助脚本。
- `runs/`：训练、验证、预测输出目录。
- `experiments_log.md`：实验记录总表，所有实验必须写入。

## 3. Baseline定义（冻结）

- model: `yolov8s`
- imgsz: `640`
- epochs: `100`
- optimizer: YOLOv8 默认
- dataset: `VisDrone2019-DET`

baseline 禁止修改。baseline 训练结果、配置、日志和权重不得被后续实验覆盖。

## 4. SOD-YOLO改进范围

- GFPN / RepGFPN（Neck）：替换或增强 YOLOv8 原始 FPN/PAN 特征融合结构。
- P2 detection head：新增高分辨率检测层，形成 P2/P3/P4/P5 检测尺度。
- C2f-EMA attention：在 C2f 相关模块中引入 EMA 注意力。
- PIoU loss：将原边界框回归损失替换或扩展为 PIoU。

除上述范围外，不得擅自引入额外结构改动作为 SOD-YOLO 复现结果。

## 5. 实验规则

- 所有实验必须记录到 `experiments_log.md`。
- 实验编号必须遵循：
  - `E00`：YOLOv8s baseline
  - `E01`：P2 detection head
  - `E10`：数据增强实验
  - `E20`：轻量化实验
- 如继续使用蓝图中的扩展编号，`E02` 表示 GFPN，`E03` 表示完整 SOD-YOLO。
- baseline 结果不可覆盖；新增实验必须使用独立输出目录。
- 每条实验记录至少包含：实验编号、改动内容、配置、数据集、训练轮数、输出路径、核心指标、结论。

## 6. Codex执行协议

- 每次执行前必须读取 `PROJECT_HANDBOOK.md` + `PROJECT_STATE.md`。
- 每次任务完成后必须更新维护文件，这是固定流程。
- 每次执行后必须更新 `PROJECT_STATE.md`，记录已完成事项、当前状态、下一步建议与风险。
- 如任务改变了项目规则、目录规范、实验规范或长期流程，必须同步更新对应维护文件，如 `PROJECT_HANDBOOK.md`、`RUNS_POLICY.md` 或 `experiments_log.md`。
- 涉及训练、验证、评估、消融或结果对比时，必须记录 `experiments_log.md`。
- 不得依赖聊天历史恢复项目状态；以本文件、`PROJECT_STATE.md`、`experiments_log.md` 和仓库实际文件为准。
- 不得修改冻结 baseline 定义；如需变更，必须先明确记录为新实验。
