# RUNS_POLICY

本文件定义 YOLOv8 + SOD-YOLO VisDrone 项目的统一实验输出规范。后续所有说明性文字默认使用中文。

## 1. 必须使用的输出格式

所有实验必须显式设置：

```text
project=runs/<type>
name=Exx_experiment_name
```

在 `train.py` 中，`project=runs/<type>` 会被强制解析为项目根目录下的绝对路径，避免 Ultralytics 在 Windows / conda 环境中回退到 `runs/detect/*`。

示例：

```text
project=runs/baseline
name=E00_yolov8s_visdrone_640
```

## 2. runs 分类标准

- `runs/baseline/`：冻结 YOLOv8s baseline 输出。
- `runs/sod/`：完整 SOD-YOLO 或阶段性 SOD 改进输出。
- `runs/lite/`：轻量化模型实验输出。
- `runs/ablation/`：消融实验输出，如 P2、GFPN、EMA、PIoU 单独或组合实验。
- `runs/tools/`：非训练工具输出，如数据集检查结果。
- `runs/predict/`：预测与可视化输出。

## 3. 禁止使用的路径

- 禁止使用 YOLO 默认实验输出路径，如 `runs/detect/*`。
- 禁止将预测结果输出到 `runs/predict/` 以外的默认路径。
- 禁止创建 `runs/runs/*` 或 `runs/detect/runs/*` 等嵌套路径。
- 禁止将 dataset check 等工具输出混入训练实验目录。
- 禁止依赖 Ultralytics 默认 `project` 解析；必须通过 `train.py` 统一入口执行训练。

## 4. 命名规则

- 实验名称必须以实验编号开头：`Exx_experiment_name`。
- `E00` 用于 baseline，`E01` / `E02` / `E03` 用于 SOD 消融或阶段性复现，`E10` 用于数据增强实验，`E20` 用于轻量化实验。
- 每个实验必须使用独立输出目录。
- 禁止覆盖冻结 baseline 输出。

## 5. Windows 训练稳定性规则

- 在 Windows 环境中，`train.py` 默认强制 `workers=0`，避免 YOLOv8 多进程 DataLoader 死锁。
- 如需启用 batch8 或长训，配置中必须显式写入 `workers: 0`。
- 推荐长训配置同时写入 `cache: true` 与 `device: 0`。
- 禁止绕过 `train.py` 直接调用 YOLO 默认训练入口，除非手动保证 `workers=0`。
