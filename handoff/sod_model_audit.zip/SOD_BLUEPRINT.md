# SOD-YOLO VISDRONE 复现任务说明
## 一、目标
在 YOLOv8 基线基础上复现 SOD-YOLO，用于 VisDrone 小目标检测，并完成消融实验对比。

## 二、总体任务流程
1. Baseline训练
- 使用 YOLOv8s（yolov8s.pt）
- 在 VisDrone 数据集上训练
- 输出 mAP / Precision / Recall

---

2. 数据处理
- VisDrone → YOLO格式转换：
  class x_center y_center width height
- 筛选类别：car / pedestrian / bicycle / motor
- 删除空标注
- 统计小/中/大目标比例

---

3. 网络结构修改（SOD核心）

（1）Neck改动
- 将 YOLOv8 FPN/PAN 替换为 优化GFPN（启发来自RepGFPN）
- 使用多路径特征融合
- 增强跨层特征交互

（2）Head改动
- 增加 P2 detection layer（高分辨率检测层）
- 原结构：
  P3 / P4 / P5
- 修改为：
  P2 / P3 / P4 / P5
- stride(P2)=4

（3）注意力模块
- 在 C2f 中加入 EMA attention（C2f-EMA）

（4）Loss改动
- 将 CIoU 替换为 PIoU
- PIoU包含角点惩罚项 + 中等IoU优化

---

4. 消融实验

    必须完成三组：

- Exp1：YOLOv8 baseline
- Exp2：+P2 detection head
- Exp3：完整SOD-YOLO（GFPN + P2 + EMA + PIoU）

---

## 三、训练配置（参考）

（1）Baseline训练
    model=yolov8s.pt \
    data=visdrone.yaml \
    epochs=100 \
    imgsz=640 \
    batch=8
    workers=0 \
    cache=True \
    device=0

---

（2）SOD-YOLO训练
    model=sod_yolov8.yaml \
    data=visdrone.yaml \
    epochs=100 \
    imgsz=640 \
    batch=8 \
    workers=0 \
    cache=True \
    optimizer=SGD \
    lr0=0.005 \
    lrf=0.01 \
    momentum=0.937 \
    weight_decay=0.0005 \
    warmup_epochs=5
    device=0


---

## 四、输出要求

1. 指标
- mAP50
- mAP50-95
- Precision
- Recall

2. 类别结果
- car
- pedestrian
- bicycle
- motor

3. 可视化
- baseline vs SOD检测对比图
- PR curve
- loss curve
- 小目标检测放大对比

---

## 六、实验编号规范

- E00：baseline
- E01：+P2 head
- E02：GFPN
- E03：full SOD
- E10：数据增强实验
- E20：轻量化实验