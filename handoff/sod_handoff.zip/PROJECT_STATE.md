# PROJECT_STATE

## 1. 当前阶段

Stage B2 消融精细调优与 SOD 交接整理阶段。

## 2. 当前任务状态

- E03_full_sod_30ep_b5：已完成，输出目录 `runs/sod/E03_full_sod_30ep_b5`。
- E03_no_piou_50ep_b5：已完成，输出目录 `runs/sod/E03_no_piou_50ep_b5`。
- E03_batch8_full_50ep：异常卡死后人为中断，记录到 epoch 22，不作为最终结果。
- E03_batch8_full_50ep_workers0：已创建配置并 dry-run 通过；后续训练需使用新目录，不覆盖旧异常目录。
- `train.py` 已支持 `workers/cache/device`，Windows 默认 `workers=0`。
- 当前任务：生成最小可运行 SOD 交接包 `handoff/sod_handoff/`。

## 3. 下一步任务

1. 将 SOD 必需代码、模型 YAML、训练配置和说明文档打包给训练队友。
2. 队友优先运行 no-PIoU SOD 50 epoch 对照。
3. 再运行 full SOD batch8 workers0 对照。
4. 若继续冲 mAP50，建议基于 no-PIoU SOD 尝试 `imgsz=768` 微调。

## 4. 已完成任务摘要

- YOLOv8s baseline 已训练完成并记录。
- GFPN-lite、P2 detection head、C2f-EMA、PIoU 已实现。
- Stage A 结构 smoke test 已完成。
- Stage B2 no-PIoU 对照已完成。
- Windows DataLoader 死锁规避已写入 `train.py` 和配置规范。

## 5. 当前问题

- full SOD + PIoU 当前表现可能弱于 baseline。
- PIoU 在当前复现条件下可能拉低 recall / mAP。
- batch8 长训在 Windows + YOLOv8 + DataLoader 场景下必须使用 `workers=0`。
- 不要复用旧目录 `runs/sod/E03_batch8_full_50ep` 作为最终结果。

## 6. 下一步建议

- 交接包只包含 SOD 必需文件，不包含 datasets、runs、权重、`.venv`、`.git`。
- 队友应使用已有 baseline 环境，缺依赖再补，不建议覆盖已跑通环境。
